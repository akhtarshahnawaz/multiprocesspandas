# Multiprocess Pandas

This library extends Pandas to run apply methods for DataFrames, Series and GroupBys on multiple cores at same time.