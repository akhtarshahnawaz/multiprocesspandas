from . import applyparallel

__all__ = [
    'applyparallel',
]